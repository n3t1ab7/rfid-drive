﻿namespace Mifare1K
{
    partial class Mifare_1K
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mifare_1K));
            this.txtSearchPurse = new System.Windows.Forms.TextBox();
            this.btnRequest = new System.Windows.Forms.Button();
            this.btnReqIDL = new System.Windows.Forms.Button();
            this.btnHalt = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCreditCardBalance = new System.Windows.Forms.Button();
            this.btnCreditCardDecrement = new System.Windows.Forms.Button();
            this.btnCreditCardIncrement = new System.Windows.Forms.Button();
            this.btnPurseInit = new System.Windows.Forms.Button();
            this.txtBoxPurseHex = new System.Windows.Forms.TextBox();
            this.txtPurseDec = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxPurseKey = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rbtPurseKeyB = new System.Windows.Forms.RadioButton();
            this.rbtPurseKeyA = new System.Windows.Forms.RadioButton();
            this.cbxSubmass1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbxMass1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtInputKey2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rbtKeyB2 = new System.Windows.Forms.RadioButton();
            this.rbtKeyA2 = new System.Windows.Forms.RadioButton();
            this.txtKeyB2 = new System.Windows.Forms.TextBox();
            this.txtKey2 = new System.Windows.Forms.TextBox();
            this.txtKeyA2 = new System.Windows.Forms.TextBox();
            this.txtDataThree2 = new System.Windows.Forms.TextBox();
            this.txtBoxDataTwo2 = new System.Windows.Forms.TextBox();
            this.txtBoxDataOne2 = new System.Windows.Forms.TextBox();
            this.btnWriteBlock2 = new System.Windows.Forms.Button();
            this.btnReadSector2 = new System.Windows.Forms.Button();
            this.cbxSubmass2 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbxMass2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tsMifare1K = new System.Windows.Forms.ToolStrip();
            this.tsbtnConnect = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.tscbxPort = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.tscbxBaud = new System.Windows.Forms.ToolStripComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tsMifare1K.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSearchPurse
            // 
            this.txtSearchPurse.Location = new System.Drawing.Point(93, 99);
            this.txtSearchPurse.Margin = new System.Windows.Forms.Padding(4);
            this.txtSearchPurse.Name = "txtSearchPurse";
            this.txtSearchPurse.Size = new System.Drawing.Size(127, 28);
            this.txtSearchPurse.TabIndex = 0;
            // 
            // btnRequest
            // 
            this.btnRequest.Location = new System.Drawing.Point(244, 99);
            this.btnRequest.Margin = new System.Windows.Forms.Padding(4);
            this.btnRequest.Name = "btnRequest";
            this.btnRequest.Size = new System.Drawing.Size(92, 34);
            this.btnRequest.TabIndex = 1;
            this.btnRequest.Text = "Read UID";
            this.btnRequest.UseVisualStyleBackColor = true;
            this.btnRequest.Click += new System.EventHandler(this.btnRequest_Click);
            // 
            // btnReqIDL
            // 
            this.btnReqIDL.Location = new System.Drawing.Point(412, 104);
            this.btnReqIDL.Margin = new System.Windows.Forms.Padding(4);
            this.btnReqIDL.Name = "btnReqIDL";
            this.btnReqIDL.Size = new System.Drawing.Size(128, 34);
            this.btnReqIDL.TabIndex = 2;
            this.btnReqIDL.Text = "ReqAll(0x52)";
            this.btnReqIDL.UseVisualStyleBackColor = true;
            this.btnReqIDL.Click += new System.EventHandler(this.btnReqIDL_Click);
            // 
            // btnHalt
            // 
            this.btnHalt.Location = new System.Drawing.Point(621, 104);
            this.btnHalt.Margin = new System.Windows.Forms.Padding(4);
            this.btnHalt.Name = "btnHalt";
            this.btnHalt.Size = new System.Drawing.Size(111, 34);
            this.btnHalt.TabIndex = 3;
            this.btnHalt.Text = "Halt card";
            this.btnHalt.UseVisualStyleBackColor = true;
            this.btnHalt.Click += new System.EventHandler(this.btnHalt_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCreditCardBalance);
            this.groupBox1.Controls.Add(this.btnCreditCardDecrement);
            this.groupBox1.Controls.Add(this.btnCreditCardIncrement);
            this.groupBox1.Controls.Add(this.btnPurseInit);
            this.groupBox1.Controls.Add(this.txtBoxPurseHex);
            this.groupBox1.Controls.Add(this.txtPurseDec);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxPurseKey);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.rbtPurseKeyB);
            this.groupBox1.Controls.Add(this.rbtPurseKeyA);
            this.groupBox1.Controls.Add(this.cbxSubmass1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cbxMass1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(93, 562);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(639, 363);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ePurse function";
            // 
            // btnCreditCardBalance
            // 
            this.btnCreditCardBalance.Location = new System.Drawing.Point(426, 298);
            this.btnCreditCardBalance.Margin = new System.Windows.Forms.Padding(4);
            this.btnCreditCardBalance.Name = "btnCreditCardBalance";
            this.btnCreditCardBalance.Size = new System.Drawing.Size(112, 34);
            this.btnCreditCardBalance.TabIndex = 15;
            this.btnCreditCardBalance.Text = "Balance";
            this.btnCreditCardBalance.UseVisualStyleBackColor = true;
            this.btnCreditCardBalance.Click += new System.EventHandler(this.btnCreditCardBalance_Click);
            // 
            // btnCreditCardDecrement
            // 
            this.btnCreditCardDecrement.Location = new System.Drawing.Point(290, 298);
            this.btnCreditCardDecrement.Margin = new System.Windows.Forms.Padding(4);
            this.btnCreditCardDecrement.Name = "btnCreditCardDecrement";
            this.btnCreditCardDecrement.Size = new System.Drawing.Size(112, 34);
            this.btnCreditCardDecrement.TabIndex = 14;
            this.btnCreditCardDecrement.Text = "Decrement";
            this.btnCreditCardDecrement.UseVisualStyleBackColor = true;
            this.btnCreditCardDecrement.Click += new System.EventHandler(this.btnCreditCardDecrement_Click);
            // 
            // btnCreditCardIncrement
            // 
            this.btnCreditCardIncrement.Location = new System.Drawing.Point(152, 298);
            this.btnCreditCardIncrement.Margin = new System.Windows.Forms.Padding(4);
            this.btnCreditCardIncrement.Name = "btnCreditCardIncrement";
            this.btnCreditCardIncrement.Size = new System.Drawing.Size(112, 34);
            this.btnCreditCardIncrement.TabIndex = 13;
            this.btnCreditCardIncrement.Text = "Increment";
            this.btnCreditCardIncrement.UseVisualStyleBackColor = true;
            this.btnCreditCardIncrement.Click += new System.EventHandler(this.btnCreditCardIncrement_Click);
            // 
            // btnPurseInit
            // 
            this.btnPurseInit.Location = new System.Drawing.Point(12, 298);
            this.btnPurseInit.Margin = new System.Windows.Forms.Padding(4);
            this.btnPurseInit.Name = "btnPurseInit";
            this.btnPurseInit.Size = new System.Drawing.Size(112, 34);
            this.btnPurseInit.TabIndex = 12;
            this.btnPurseInit.Text = "Initialize";
            this.btnPurseInit.UseVisualStyleBackColor = true;
            this.btnPurseInit.Click += new System.EventHandler(this.btnPurseInit_Click);
            // 
            // txtBoxPurseHex
            // 
            this.txtBoxPurseHex.Location = new System.Drawing.Point(288, 212);
            this.txtBoxPurseHex.Margin = new System.Windows.Forms.Padding(4);
            this.txtBoxPurseHex.Name = "txtBoxPurseHex";
            this.txtBoxPurseHex.Size = new System.Drawing.Size(258, 28);
            this.txtBoxPurseHex.TabIndex = 11;
            // 
            // txtPurseDec
            // 
            this.txtPurseDec.Location = new System.Drawing.Point(12, 212);
            this.txtPurseDec.Margin = new System.Windows.Forms.Padding(4);
            this.txtPurseDec.Name = "txtPurseDec";
            this.txtPurseDec.Size = new System.Drawing.Size(270, 28);
            this.txtPurseDec.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(288, 176);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 18);
            this.label5.TabIndex = 9;
            this.label5.Text = "Value(Hex)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 176);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 18);
            this.label4.TabIndex = 8;
            this.label4.Text = "Value(Dec,input)";
            // 
            // textBoxPurseKey
            // 
            this.textBoxPurseKey.Location = new System.Drawing.Point(266, 110);
            this.textBoxPurseKey.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPurseKey.Name = "textBoxPurseKey";
            this.textBoxPurseKey.Size = new System.Drawing.Size(160, 28);
            this.textBoxPurseKey.TabIndex = 7;
            this.textBoxPurseKey.Text = "FFFFFFFFFFFF";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(222, 114);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Key";
            // 
            // rbtPurseKeyB
            // 
            this.rbtPurseKeyB.AutoSize = true;
            this.rbtPurseKeyB.Location = new System.Drawing.Point(105, 111);
            this.rbtPurseKeyB.Margin = new System.Windows.Forms.Padding(4);
            this.rbtPurseKeyB.Name = "rbtPurseKeyB";
            this.rbtPurseKeyB.Size = new System.Drawing.Size(69, 22);
            this.rbtPurseKeyB.TabIndex = 5;
            this.rbtPurseKeyB.Text = "KeyB";
            this.rbtPurseKeyB.UseVisualStyleBackColor = true;
            // 
            // rbtPurseKeyA
            // 
            this.rbtPurseKeyA.AutoSize = true;
            this.rbtPurseKeyA.Checked = true;
            this.rbtPurseKeyA.Location = new System.Drawing.Point(12, 111);
            this.rbtPurseKeyA.Margin = new System.Windows.Forms.Padding(4);
            this.rbtPurseKeyA.Name = "rbtPurseKeyA";
            this.rbtPurseKeyA.Size = new System.Drawing.Size(69, 22);
            this.rbtPurseKeyA.TabIndex = 4;
            this.rbtPurseKeyA.TabStop = true;
            this.rbtPurseKeyA.Text = "KeyA";
            this.rbtPurseKeyA.UseVisualStyleBackColor = true;
            // 
            // cbxSubmass1
            // 
            this.cbxSubmass1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSubmass1.FormattingEnabled = true;
            this.cbxSubmass1.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cbxSubmass1.Location = new System.Drawing.Point(256, 52);
            this.cbxSubmass1.Margin = new System.Windows.Forms.Padding(4);
            this.cbxSubmass1.MaxDropDownItems = 3;
            this.cbxSubmass1.Name = "cbxSubmass1";
            this.cbxSubmass1.Size = new System.Drawing.Size(98, 26);
            this.cbxSubmass1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Block";
            // 
            // cbxMass1
            // 
            this.cbxMass1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMass1.FormattingEnabled = true;
            this.cbxMass1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbxMass1.Location = new System.Drawing.Point(81, 52);
            this.cbxMass1.Margin = new System.Windows.Forms.Padding(4);
            this.cbxMass1.MaxDropDownItems = 16;
            this.cbxMass1.Name = "cbxMass1";
            this.cbxMass1.Size = new System.Drawing.Size(98, 26);
            this.cbxMass1.TabIndex = 1;
            this.cbxMass1.SelectedIndexChanged += new System.EventHandler(this.cbxMass1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sector";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtInputKey2);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.rbtKeyB2);
            this.groupBox2.Controls.Add(this.rbtKeyA2);
            this.groupBox2.Controls.Add(this.txtKeyB2);
            this.groupBox2.Controls.Add(this.txtKey2);
            this.groupBox2.Controls.Add(this.txtKeyA2);
            this.groupBox2.Controls.Add(this.txtDataThree2);
            this.groupBox2.Controls.Add(this.txtBoxDataTwo2);
            this.groupBox2.Controls.Add(this.txtBoxDataOne2);
            this.groupBox2.Controls.Add(this.btnWriteBlock2);
            this.groupBox2.Controls.Add(this.btnReadSector2);
            this.groupBox2.Controls.Add(this.cbxSubmass2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cbxMass2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(93, 165);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(639, 363);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Block read/write";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(-370, 699);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(344, 28);
            this.textBox1.TabIndex = 31;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(-412, 705);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 18);
            this.label9.TabIndex = 30;
            this.label9.Text = "Key";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(-540, 699);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(69, 22);
            this.radioButton1.TabIndex = 29;
            this.radioButton1.Text = "KeyB";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(-633, 699);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(69, 22);
            this.radioButton2.TabIndex = 28;
            this.radioButton2.Text = "KeyA";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(-216, 626);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(190, 28);
            this.textBox2.TabIndex = 27;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(-426, 626);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(204, 28);
            this.textBox3.TabIndex = 26;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(-633, 626);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(200, 28);
            this.textBox4.TabIndex = 25;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(-633, 582);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(608, 28);
            this.textBox5.TabIndex = 24;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(-633, 538);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(608, 28);
            this.textBox6.TabIndex = 23;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(-634, 495);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(608, 28);
            this.textBox7.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(-154, 447);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 34);
            this.button1.TabIndex = 21;
            this.button1.Text = "Write Block";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(-298, 447);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 34);
            this.button2.TabIndex = 20;
            this.button2.Text = "Read Sector";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(-405, 447);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(96, 26);
            this.comboBox1.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(-460, 452);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 18);
            this.label10.TabIndex = 18;
            this.label10.Text = "Block";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(-567, 447);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(96, 26);
            this.comboBox2.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(-638, 452);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 18);
            this.label11.TabIndex = 16;
            this.label11.Text = "Sector";
            // 
            // txtInputKey2
            // 
            this.txtInputKey2.Location = new System.Drawing.Point(278, 304);
            this.txtInputKey2.Margin = new System.Windows.Forms.Padding(4);
            this.txtInputKey2.Name = "txtInputKey2";
            this.txtInputKey2.Size = new System.Drawing.Size(148, 28);
            this.txtInputKey2.TabIndex = 15;
            this.txtInputKey2.Text = "FFFFFFFFFFFF";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(236, 310);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "Key";
            // 
            // rbtKeyB2
            // 
            this.rbtKeyB2.AutoSize = true;
            this.rbtKeyB2.Location = new System.Drawing.Point(108, 304);
            this.rbtKeyB2.Margin = new System.Windows.Forms.Padding(4);
            this.rbtKeyB2.Name = "rbtKeyB2";
            this.rbtKeyB2.Size = new System.Drawing.Size(69, 22);
            this.rbtKeyB2.TabIndex = 13;
            this.rbtKeyB2.Text = "KeyB";
            this.rbtKeyB2.UseVisualStyleBackColor = true;
            // 
            // rbtKeyA2
            // 
            this.rbtKeyA2.AutoSize = true;
            this.rbtKeyA2.Checked = true;
            this.rbtKeyA2.Location = new System.Drawing.Point(15, 304);
            this.rbtKeyA2.Margin = new System.Windows.Forms.Padding(4);
            this.rbtKeyA2.Name = "rbtKeyA2";
            this.rbtKeyA2.Size = new System.Drawing.Size(69, 22);
            this.rbtKeyA2.TabIndex = 12;
            this.rbtKeyA2.TabStop = true;
            this.rbtKeyA2.Text = "KeyA";
            this.rbtKeyA2.UseVisualStyleBackColor = true;
            // 
            // txtKeyB2
            // 
            this.txtKeyB2.Location = new System.Drawing.Point(432, 231);
            this.txtKeyB2.Margin = new System.Windows.Forms.Padding(4);
            this.txtKeyB2.Name = "txtKeyB2";
            this.txtKeyB2.Size = new System.Drawing.Size(190, 28);
            this.txtKeyB2.TabIndex = 11;
            // 
            // txtKey2
            // 
            this.txtKey2.Location = new System.Drawing.Point(222, 231);
            this.txtKey2.Margin = new System.Windows.Forms.Padding(4);
            this.txtKey2.Name = "txtKey2";
            this.txtKey2.Size = new System.Drawing.Size(204, 28);
            this.txtKey2.TabIndex = 10;
            // 
            // txtKeyA2
            // 
            this.txtKeyA2.Location = new System.Drawing.Point(15, 231);
            this.txtKeyA2.Margin = new System.Windows.Forms.Padding(4);
            this.txtKeyA2.Name = "txtKeyA2";
            this.txtKeyA2.Size = new System.Drawing.Size(200, 28);
            this.txtKeyA2.TabIndex = 9;
            // 
            // txtDataThree2
            // 
            this.txtDataThree2.Location = new System.Drawing.Point(15, 188);
            this.txtDataThree2.Margin = new System.Windows.Forms.Padding(4);
            this.txtDataThree2.Name = "txtDataThree2";
            this.txtDataThree2.Size = new System.Drawing.Size(608, 28);
            this.txtDataThree2.TabIndex = 8;
            // 
            // txtBoxDataTwo2
            // 
            this.txtBoxDataTwo2.Location = new System.Drawing.Point(15, 144);
            this.txtBoxDataTwo2.Margin = new System.Windows.Forms.Padding(4);
            this.txtBoxDataTwo2.Name = "txtBoxDataTwo2";
            this.txtBoxDataTwo2.Size = new System.Drawing.Size(608, 28);
            this.txtBoxDataTwo2.TabIndex = 7;
            // 
            // txtBoxDataOne2
            // 
            this.txtBoxDataOne2.Location = new System.Drawing.Point(14, 100);
            this.txtBoxDataOne2.Margin = new System.Windows.Forms.Padding(4);
            this.txtBoxDataOne2.Name = "txtBoxDataOne2";
            this.txtBoxDataOne2.Size = new System.Drawing.Size(608, 28);
            this.txtBoxDataOne2.TabIndex = 6;
            // 
            // btnWriteBlock2
            // 
            this.btnWriteBlock2.Location = new System.Drawing.Point(494, 52);
            this.btnWriteBlock2.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteBlock2.Name = "btnWriteBlock2";
            this.btnWriteBlock2.Size = new System.Drawing.Size(130, 34);
            this.btnWriteBlock2.TabIndex = 5;
            this.btnWriteBlock2.Text = "Write Block";
            this.btnWriteBlock2.UseVisualStyleBackColor = true;
            this.btnWriteBlock2.Click += new System.EventHandler(this.btnWriteBlock2_Click);
            // 
            // btnReadSector2
            // 
            this.btnReadSector2.Location = new System.Drawing.Point(350, 52);
            this.btnReadSector2.Margin = new System.Windows.Forms.Padding(4);
            this.btnReadSector2.Name = "btnReadSector2";
            this.btnReadSector2.Size = new System.Drawing.Size(130, 34);
            this.btnReadSector2.TabIndex = 4;
            this.btnReadSector2.Text = "Read Sector";
            this.btnReadSector2.UseVisualStyleBackColor = true;
            this.btnReadSector2.Click += new System.EventHandler(this.btnReadSector2_Click);
            // 
            // cbxSubmass2
            // 
            this.cbxSubmass2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSubmass2.FormattingEnabled = true;
            this.cbxSubmass2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cbxSubmass2.Location = new System.Drawing.Point(243, 52);
            this.cbxSubmass2.Margin = new System.Windows.Forms.Padding(4);
            this.cbxSubmass2.MaxDropDownItems = 4;
            this.cbxSubmass2.Name = "cbxSubmass2";
            this.cbxSubmass2.Size = new System.Drawing.Size(96, 26);
            this.cbxSubmass2.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(188, 57);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "Block";
            // 
            // cbxMass2
            // 
            this.cbxMass2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMass2.FormattingEnabled = true;
            this.cbxMass2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbxMass2.Location = new System.Drawing.Point(81, 52);
            this.cbxMass2.Margin = new System.Windows.Forms.Padding(4);
            this.cbxMass2.MaxDropDownItems = 16;
            this.cbxMass2.Name = "cbxMass2";
            this.cbxMass2.Size = new System.Drawing.Size(96, 26);
            this.cbxMass2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 57);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 18);
            this.label6.TabIndex = 0;
            this.label6.Text = "Sector";
            // 
            // tsMifare1K
            // 
            this.tsMifare1K.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.tsMifare1K.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnConnect,
            this.toolStripSeparator1,
            this.toolStripLabel1,
            this.tscbxPort,
            this.toolStripLabel2,
            this.tscbxBaud});
            this.tsMifare1K.Location = new System.Drawing.Point(0, 0);
            this.tsMifare1K.Name = "tsMifare1K";
            this.tsMifare1K.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.tsMifare1K.Size = new System.Drawing.Size(795, 32);
            this.tsMifare1K.TabIndex = 33;
            this.tsMifare1K.Text = "Mifare1K";
            // 
            // tsbtnConnect
            // 
            this.tsbtnConnect.BackColor = System.Drawing.SystemColors.Control;
            this.tsbtnConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtnConnect.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnConnect.Image")));
            this.tsbtnConnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnConnect.Name = "tsbtnConnect";
            this.tsbtnConnect.Size = new System.Drawing.Size(85, 29);
            this.tsbtnConnect.Text = "Connect";
            this.tsbtnConnect.Click += new System.EventHandler(this.tsbtnConnect_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(46, 29);
            this.toolStripLabel1.Text = "Port";
            // 
            // tscbxPort
            // 
            this.tscbxPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tscbxPort.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.tscbxPort.Name = "tscbxPort";
            this.tscbxPort.Size = new System.Drawing.Size(180, 32);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(54, 29);
            this.toolStripLabel2.Text = "Baud";
            // 
            // tscbxBaud
            // 
            this.tscbxBaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tscbxBaud.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200"});
            this.tscbxBaud.Name = "tscbxBaud";
            this.tscbxBaud.Size = new System.Drawing.Size(180, 32);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(102, 64);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 18);
            this.label13.TabIndex = 35;
            this.label13.Text = "Mifare UID";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(198, 144);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(224, 18);
            this.label16.TabIndex = 36;
            this.label16.Text = "(Request-Anticol-Select)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 400);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 18);
            this.label17.TabIndex = 37;
            this.label17.Text = "Key block";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(280, 64);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(278, 18);
            this.label22.TabIndex = 39;
            this.label22.Text = "Mifare one read and write area";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(606, 14);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(143, 18);
            this.label23.TabIndex = 40;
            this.label23.Text = "Tested on ER302";
            // 
            // Mifare_1K
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(795, 964);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tsMifare1K);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnHalt);
            this.Controls.Add(this.btnReqIDL);
            this.Controls.Add(this.btnRequest);
            this.Controls.Add(this.txtSearchPurse);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Mifare_1K";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mifare_DEMO www.ehuoyan.com";
            this.Load += new System.EventHandler(this.Mifare_1K_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tsMifare1K.ResumeLayout(false);
            this.tsMifare1K.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearchPurse;
        private System.Windows.Forms.Button btnRequest;
        private System.Windows.Forms.Button btnReqIDL;
        private System.Windows.Forms.Button btnHalt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbtPurseKeyB;
        private System.Windows.Forms.RadioButton rbtPurseKeyA;
        private System.Windows.Forms.ComboBox cbxSubmass1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbxMass1;
        private System.Windows.Forms.TextBox txtBoxPurseHex;
        private System.Windows.Forms.TextBox txtPurseDec;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxPurseKey;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCreditCardBalance;
        private System.Windows.Forms.Button btnCreditCardDecrement;
        private System.Windows.Forms.Button btnCreditCardIncrement;
        private System.Windows.Forms.Button btnPurseInit;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbxMass2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnWriteBlock2;
        private System.Windows.Forms.Button btnReadSector2;
        private System.Windows.Forms.ComboBox cbxSubmass2;
        private System.Windows.Forms.TextBox txtKeyB2;
        private System.Windows.Forms.TextBox txtKey2;
        private System.Windows.Forms.TextBox txtKeyA2;
        private System.Windows.Forms.TextBox txtDataThree2;
        private System.Windows.Forms.TextBox txtBoxDataTwo2;
        private System.Windows.Forms.TextBox txtBoxDataOne2;
        private System.Windows.Forms.TextBox txtInputKey2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rbtKeyB2;
        private System.Windows.Forms.RadioButton rbtKeyA2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolStrip tsMifare1K;
        private System.Windows.Forms.ToolStripButton tsbtnConnect;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox tscbxPort;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox tscbxBaud;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
    }
}

